#define NULL ((void*)0)
typedef unsigned long size_t;  // Customize by platform.
typedef long intptr_t; typedef unsigned long uintptr_t;
typedef long scalar_t__;  // Either arithmetic or pointer type.
/* By default, we understand bool (as a convenience). */
typedef int bool;
#define false 0
#define true 1

/* Forward declarations */
typedef  struct TYPE_83__   TYPE_9__ ;
typedef  struct TYPE_82__   TYPE_8__ ;
typedef  struct TYPE_81__   TYPE_7__ ;
typedef  struct TYPE_80__   TYPE_6__ ;
typedef  struct TYPE_79__   TYPE_5__ ;
typedef  struct TYPE_78__   TYPE_4__ ;
typedef  struct TYPE_77__   TYPE_42__ ;
typedef  struct TYPE_76__   TYPE_3__ ;
typedef  struct TYPE_75__   TYPE_35__ ;
typedef  struct TYPE_74__   TYPE_30__ ;
typedef  struct TYPE_73__   TYPE_2__ ;
typedef  struct TYPE_72__   TYPE_29__ ;
typedef  struct TYPE_71__   TYPE_28__ ;
typedef  struct TYPE_70__   TYPE_27__ ;
typedef  struct TYPE_69__   TYPE_26__ ;
typedef  struct TYPE_68__   TYPE_25__ ;
typedef  struct TYPE_67__   TYPE_24__ ;
typedef  struct TYPE_66__   TYPE_23__ ;
typedef  struct TYPE_65__   TYPE_22__ ;
typedef  struct TYPE_64__   TYPE_21__ ;
typedef  struct TYPE_63__   TYPE_20__ ;
typedef  struct TYPE_62__   TYPE_1__ ;
typedef  struct TYPE_61__   TYPE_19__ ;
typedef  struct TYPE_60__   TYPE_18__ ;
typedef  struct TYPE_59__   TYPE_17__ ;
typedef  struct TYPE_58__   TYPE_16__ ;
typedef  struct TYPE_57__   TYPE_15__ ;
typedef  struct TYPE_56__   TYPE_14__ ;
typedef  struct TYPE_55__   TYPE_13__ ;
typedef  struct TYPE_54__   TYPE_12__ ;
typedef  struct TYPE_53__   TYPE_11__ ;
typedef  struct TYPE_52__   TYPE_10__ ;

/* Type definitions */
struct TYPE_83__ {int DEVTm4; } ;
struct TYPE_52__ {TYPE_9__ V9ej93; } ;
struct TYPE_53__ {TYPE_10__ _8WVQ2; } ;
struct TYPE_82__ {int /*<<< orphan*/  eSf3B1; } ;
struct TYPE_54__ {TYPE_11__ fbiOR4; TYPE_8__ zACHc3; } ;
struct TYPE_70__ {TYPE_12__ _8WVQ2; struct TYPE_70__* Lrwko2; int /*<<< orphan*/  MDSlK2; } ;
typedef  TYPE_27__ tJ1Kb4 ;
struct TYPE_77__ {TYPE_30__* pBSeu3; } ;
struct TYPE_66__ {TYPE_24__* WHQ_F1; TYPE_22__* pBSeu3; } ;
struct TYPE_71__ {scalar_t__ DL14H3; scalar_t__ jXwP42; TYPE_17__** eWAnF; TYPE_35__* pnKue2; TYPE_35__* _jfrJ1; TYPE_42__ Nlajt1; TYPE_23__ CUhqx4; int /*<<< orphan*/ * ikuha3; } ;
typedef  TYPE_28__ kWMzp1 ;
struct TYPE_79__ {int /*<<< orphan*/  eSf3B1; } ;
struct TYPE_73__ {int /*<<< orphan*/  DEVTm4; } ;
struct TYPE_76__ {TYPE_2__ V9ej93; } ;
struct TYPE_78__ {TYPE_3__ _8WVQ2; } ;
struct TYPE_80__ {TYPE_5__ zACHc3; TYPE_4__ fbiOR4; } ;
struct TYPE_81__ {TYPE_6__ _8WVQ2; } ;
struct TYPE_75__ {TYPE_16__* WHQ_F1; TYPE_15__* pBSeu3; } ;
struct TYPE_69__ {scalar_t__ yjr7l4; TYPE_16__* neQ2f1; TYPE_15__* OXCDa4; TYPE_7__* qXXnD2; TYPE_1__* GEbPX4; } ;
struct TYPE_68__ {TYPE_24__* neQ2f1; TYPE_22__* OXCDa4; } ;
struct TYPE_74__ {scalar_t__ Xx6Ti3; TYPE_29__* a02Gz4; TYPE_26__ NpyOc1; TYPE_25__ woMv11; } ;
struct TYPE_60__ {int LigBO2; } ;
struct TYPE_61__ {TYPE_18__ NNh015; } ;
struct TYPE_72__ {unsigned long j5MYx; struct TYPE_72__* bPudJ3; TYPE_19__ NpyOc1; } ;
struct TYPE_63__ {TYPE_22__* OXCDa4; } ;
struct TYPE_67__ {TYPE_20__ woMv11; } ;
struct TYPE_64__ {TYPE_24__* neQ2f1; } ;
struct TYPE_65__ {TYPE_21__ woMv11; } ;
struct TYPE_62__ {TYPE_27__* Lrwko2; } ;
struct TYPE_59__ {TYPE_29__* a02Gz4; } ;
struct TYPE_55__ {TYPE_15__* OXCDa4; } ;
struct TYPE_58__ {TYPE_13__ NpyOc1; } ;
struct TYPE_56__ {TYPE_16__* neQ2f1; } ;
struct TYPE_57__ {TYPE_14__ NpyOc1; } ;
typedef  TYPE_29__ QDNE6 ;
typedef  TYPE_30__ DCf0T2 ;

/* Variables and functions */
 int /*<<< orphan*/  BTL3a (TYPE_30__*,int /*<<< orphan*/ *,int /*<<< orphan*/ *) ; 
 int /*<<< orphan*/  G7h9S3 (TYPE_28__*,TYPE_30__*) ; 
 int /*<<< orphan*/  LjWek1 (TYPE_28__*,TYPE_30__*,size_t) ; 
 int /*<<< orphan*/  YBrPF4 (TYPE_28__*) ; 
 scalar_t__ cFFDu1 (TYPE_42__*,TYPE_30__*) ; 
 int /*<<< orphan*/  fOVyT4 (TYPE_28__*,size_t,TYPE_27__*) ; 
 int /*<<< orphan*/  gYC_T3 (TYPE_28__*,size_t) ; 
 TYPE_27__* osQ5M (TYPE_28__*,int /*<<< orphan*/ ) ; 
 int /*<<< orphan*/  ppetC1 (TYPE_35__*,TYPE_30__*) ; 
 int /*<<< orphan*/  q0ypK (TYPE_28__*,size_t) ; 
 int /*<<< orphan*/  uKg3m2 (TYPE_28__*,TYPE_30__*) ; 
 int /*<<< orphan*/  yoLEn3 (TYPE_28__*) ; 

__attribute__((used)) static int QrVoB3(kWMzp1*J7Iki4,QDNE6*a02Gz4,int pTM6S){DCf0T2*esWTk2
;esWTk2=(DCf0T2* )a02Gz4->bPudJ3;{if(!(!BTL3a(esWTk2,&J7Iki4->ikuha3
[0],&J7Iki4->ikuha3[(sizeof(J7Iki4->ikuha3)/sizeof(J7Iki4->ikuha3[0]))]
)))goto CVByc4;{return 0;}CVByc4:;};{if(!(esWTk2->a02Gz4!=a02Gz4))goto
z6j0y3;{return 0;}z6j0y3:;}{if(!(esWTk2->Xx6Ti3==0))goto la1Uw1;{
unsigned X3V8j4;{X3V8j4=0;sZ3K45:if(!(X3V8j4<32))goto cu7WU1;goto
RXkRU4;B2kwf3:X3V8j4++;goto sZ3K45;RXkRU4:{}goto B2kwf3;cu7WU1:;};
esWTk2->a02Gz4=0;{{if(!((esWTk2)->woMv11.neQ2f1))goto M8iX62;(
esWTk2)->woMv11.neQ2f1->woMv11.OXCDa4=(esWTk2)->woMv11.OXCDa4;goto
q1RMD2;M8iX62:;{J7Iki4->CUhqx4.pBSeu3=(esWTk2)->woMv11.OXCDa4;}
q1RMD2:;}{if(!((esWTk2)->woMv11.OXCDa4))goto WyCc21;(esWTk2)->woMv11.
OXCDa4->woMv11.neQ2f1=(esWTk2)->woMv11.neQ2f1;goto lMy6s;WyCc21:;{
J7Iki4->CUhqx4.WHQ_F1=(esWTk2)->woMv11.neQ2f1;}lMy6s:;};};G7h9S3(
J7Iki4,esWTk2);{if(!(J7Iki4->DL14H3==0))goto JBhqV2;YBrPF4(J7Iki4);
JBhqV2:;};a02Gz4->j5MYx|=16ul;a02Gz4->bPudJ3=0;return 01;}la1Uw1:;};{
if(!(!pTM6S&&(esWTk2->NpyOc1.yjr7l4!=0||esWTk2->NpyOc1.yjr7l4!=0)))goto
e71Qn1;{return 0;}e71Qn1:;}{if(!(cFFDu1(&J7Iki4->Nlajt1,esWTk2)||
J7Iki4->Nlajt1.pBSeu3==esWTk2))goto VMudP1;{{if(!(!pTM6S))goto uUOUZ4
;{return 0;}uUOUZ4:;}}VMudP1:;}a02Gz4->j5MYx|=16ul;{if(!(a02Gz4->
NpyOc1.NNh015.LigBO2<32))goto j6irJ2;{{if(!(ppetC1(&J7Iki4->_jfrJ1[
a02Gz4->NpyOc1.NNh015.LigBO2],esWTk2)))goto TG9c75;{esWTk2->Xx6Ti3--
;{if(!(esWTk2->NpyOc1.GEbPX4))goto x9Kpa;{tJ1Kb4*tfu023;tfu023=
osQ5M(J7Iki4,esWTk2->NpyOc1.qXXnD2->_8WVQ2.zACHc3.eSf3B1);{if(!(
esWTk2->NpyOc1.GEbPX4->Lrwko2))goto icC2Q1;{tJ1Kb4*o0Fou4=esWTk2->
NpyOc1.GEbPX4->Lrwko2;o0Fou4->_8WVQ2.zACHc3.eSf3B1=tfu023->MDSlK2;{
hPE_d2:{__asm __volatile(""::);__asm __volatile(
"lock; addl $0,(%%esp)": : :"cc");__asm __volatile(""::);}if(0)goto
hPE_d2;};tfu023->Lrwko2=o0Fou4;}goto ldfza;icC2Q1:;tfu023->Lrwko2=0;
ldfza:;}uKg3m2(J7Iki4,esWTk2);}goto Dz6V81;x9Kpa:;{}Dz6V81:;}{{if
(!((esWTk2)->NpyOc1.neQ2f1))goto nR9ID4;(esWTk2)->NpyOc1.neQ2f1->
NpyOc1.OXCDa4=(esWTk2)->NpyOc1.OXCDa4;goto AFhrh2;nR9ID4:;{J7Iki4->
_jfrJ1[a02Gz4->NpyOc1.NNh015.LigBO2].pBSeu3=(esWTk2)->NpyOc1.OXCDa4;}
AFhrh2:;}{if(!((esWTk2)->NpyOc1.OXCDa4))goto gU0RO;(esWTk2)->NpyOc1.
OXCDa4->NpyOc1.neQ2f1=(esWTk2)->NpyOc1.neQ2f1;goto CTqht4;gU0RO:;{
J7Iki4->_jfrJ1[a02Gz4->NpyOc1.NNh015.LigBO2].WHQ_F1=(esWTk2)->NpyOc1.
neQ2f1;}CTqht4:;};};q0ypK(J7Iki4,a02Gz4->NpyOc1.NNh015.LigBO2);}
TG9c75:;}{if(!(ppetC1(&J7Iki4->pnKue2[a02Gz4->NpyOc1.NNh015.LigBO2],
esWTk2)))goto rSBLa2;{esWTk2->Xx6Ti3--;{if(!(esWTk2->NpyOc1.GEbPX4))goto
KhdVP3;{tJ1Kb4*tfu023=0;tJ1Kb4*o0Fou4=esWTk2->NpyOc1.GEbPX4->Lrwko2;
;{if(!(!esWTk2->NpyOc1.qXXnD2->_8WVQ2.fbiOR4._8WVQ2.V9ej93.DEVTm4))goto
wwmRl3;{tfu023=osQ5M(J7Iki4,esWTk2->NpyOc1.qXXnD2->_8WVQ2.zACHc3.
eSf3B1);{if(!(o0Fou4))goto QlpOn3;{o0Fou4->_8WVQ2.zACHc3.eSf3B1=
tfu023->MDSlK2;{_fJ2B4:{__asm __volatile(""::);__asm __volatile(
"lock; addl $0,(%%esp)": : :"cc");__asm __volatile(""::);}if(0)goto
_fJ2B4;};tfu023->Lrwko2=o0Fou4;}goto Ltkwl1;QlpOn3:;tfu023->Lrwko2=0;
Ltkwl1:;}}goto GNmUv4;wwmRl3:;{{if(!(o0Fou4))goto Sg7Ii;{o0Fou4->
_8WVQ2.fbiOR4._8WVQ2.V9ej93.DEVTm4|=0x1;fOVyT4(J7Iki4,a02Gz4->NpyOc1.
NNh015.LigBO2,o0Fou4);}Sg7Ii:;}}GNmUv4:;}LjWek1(J7Iki4,esWTk2,a02Gz4
->NpyOc1.NNh015.LigBO2);}goto URiEj;KhdVP3:;{}URiEj:;}{{if(!((
esWTk2)->NpyOc1.neQ2f1))goto MpGe72;(esWTk2)->NpyOc1.neQ2f1->NpyOc1.
OXCDa4=(esWTk2)->NpyOc1.OXCDa4;goto zDomy3;MpGe72:;{J7Iki4->pnKue2[
a02Gz4->NpyOc1.NNh015.LigBO2].pBSeu3=(esWTk2)->NpyOc1.OXCDa4;}zDomy3:
;}{if(!((esWTk2)->NpyOc1.OXCDa4))goto CjH_c4;(esWTk2)->NpyOc1.OXCDa4
->NpyOc1.neQ2f1=(esWTk2)->NpyOc1.neQ2f1;goto oVe401;CjH_c4:;{J7Iki4
->pnKue2[a02Gz4->NpyOc1.NNh015.LigBO2].WHQ_F1=(esWTk2)->NpyOc1.neQ2f1
;}oVe401:;};};gYC_T3(J7Iki4,a02Gz4->NpyOc1.NNh015.LigBO2);}rSBLa2:;
}{if(!(J7Iki4->eWAnF[a02Gz4->NpyOc1.NNh015.LigBO2]))goto QGTZB3;{
esWTk2->a02Gz4=0;{if(!(esWTk2->Xx6Ti3==0))goto G3EMd;G7h9S3(J7Iki4,
esWTk2);G3EMd:;}a02Gz4->bPudJ3=J7Iki4->eWAnF[a02Gz4->NpyOc1.NNh015.
LigBO2]->a02Gz4;J7Iki4->eWAnF[a02Gz4->NpyOc1.NNh015.LigBO2]->a02Gz4=
a02Gz4;return 0;}QGTZB3:;}}j6irJ2:;}esWTk2->a02Gz4=0;{if(!(esWTk2->
Xx6Ti3==0))goto uIVHm2;G7h9S3(J7Iki4,esWTk2);uIVHm2:;};a02Gz4->bPudJ3
=0;{if(!(J7Iki4->jXwP42==0))goto tLnQG3;yoLEn3(J7Iki4);tLnQG3:;}
return 0x1;}